<?php

$url="https://www.irctctourism.com/tourism/pkgUser/pckgs/book";
   

// Create a new cURL resource
$ch = curl_init($url);
//SHG07
// Setup request to send json via POST
$data = array(
    'pckgCode' => 'SHG07',
    'token' => ''
);
$payload = json_encode($data);

echo $payload;

// Attach encoded JSON string to the POST fields
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

// Set the content type to application/json
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

// Return response instead of outputting
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute the POST request
$result = curl_exec($ch);
echo $result;

// Close cURL resource
curl_close($ch);


$jsonObj=json_decode($result);
$dateArr=$jsonObj->data->JOURNEY_DATE;
$targetDate="10-DEC-21";
foreach ($dateArr as $value) {
	if($value->J_DATE == $targetDate)
    	mail("chandu180180@gmail.com","IRCTC Jai Alert !!!!"," click -> https://www.irctctourism.com/tourpackageBooking?packageCode=SHG07" );
    if($value->J_DATE == '09-DEC-21')
    	mail("chandu180180@gmail.com","IRCTC Jai Alert !!!!"," click -> https://www.irctctourism.com/tourpackageBooking?packageCode=SHG07" );
}

// send email

?>